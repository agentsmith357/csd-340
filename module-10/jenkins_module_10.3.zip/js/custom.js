$(document).ready(function() {
      $('#neo').click(function() {
        $('#output').text("You mean I can dodge bullets?");
      });

      $('#smith').click(function() {
        $('#output').text("Mr. Anderson.  We missed you!");
      });
    });